# 🪣 BucketList

Offline bucket list + trip planner app. Data sirf phone me, backup file se wapas.

## Install (Android APK)
1. Is folder ki saari files GitHub repo me upload karo.
2. Repo → Actions → "set up a workflow yourself" → `build-apk.yml` ka content paste karo → Commit.
3. Build khatam hone par (5-8 min) repo ke Releases me `BucketList.apk` milegi. Download karke install karo.
