/* Trips section: plan (din-wise), kharcha, packing, yaad rakhna.
   Pehle load hota hai (app.js se pehle), app.js baad me BLTrips.init(...) call karta hai. */
(() => {
'use strict';

const CUR = ['₹', '$', '€', '£', '¥', 'AED', '฿'];
const EXP_CATS = [
  { id: 'travel', emoji: '🚆', name: 'Travel', hue: 200 },
  { id: 'stay',   emoji: '🏨', name: 'Stay', hue: 262 },
  { id: 'food',   emoji: '🍜', name: 'Khana', hue: 25 },
  { id: 'fun',    emoji: '🎟️', name: 'Entry / Masti', hue: 330 },
  { id: 'shop',   emoji: '🛍️', name: 'Shopping', hue: 45 },
  { id: 'other',  emoji: '🎁', name: 'Other', hue: 150 },
];
const PACK_GRP = [
  { id: 'docs',    emoji: '📄', name: 'Documents' },
  { id: 'clothes', emoji: '👕', name: 'Kapde' },
  { id: 'gadgets', emoji: '🔌', name: 'Gadgets' },
  { id: 'care',    emoji: '🧴', name: 'Toiletries' },
  { id: 'med',     emoji: '💊', name: 'Dawai' },
  { id: 'other',   emoji: '🎒', name: 'Other' },
];
const PACK_TPL = {
  basic:  { label: '✨ Basics', hue: 330, items: [['docs', 'ID proof (Aadhaar / DL)'], ['docs', 'Tickets aur booking ke screenshots'], ['gadgets', 'Phone charger'], ['gadgets', 'Power bank'], ['care', 'Brush + paste'], ['care', 'Sunscreen'], ['med', 'Paracetamol'], ['med', 'ORS'], ['clothes', 'Extra kapde'], ['clothes', 'Undergarments'], ['clothes', 'Aaram wale joote / chappal'], ['other', 'Water bottle'], ['other', 'Cash + cards']] },
  beach:  { label: '🏖️ Beach', hue: 200, items: [['clothes', 'Swimwear'], ['clothes', 'Flip-flops'], ['clothes', 'Topi / hat'], ['care', 'After-sun lotion'], ['gadgets', 'Waterproof phone pouch'], ['other', 'Sunglasses'], ['other', 'Beach towel']] },
  trek:   { label: '🏔️ Trek', hue: 150, items: [['clothes', 'Trekking shoes'], ['clothes', 'Rain jacket'], ['clothes', 'Garam layers'], ['clothes', 'Extra socks'], ['gadgets', 'Torch / headlamp'], ['med', 'First-aid kit'], ['other', 'Energy bars / snacks'], ['other', 'Backpack rain cover'], ['other', 'Walking stick']] },
  abroad: { label: '🌍 Abroad', hue: 262, items: [['docs', 'Passport'], ['docs', 'Visa'], ['docs', 'Travel insurance'], ['docs', 'Hotel booking printout'], ['gadgets', 'Universal plug adapter'], ['other', 'Forex card / cash'], ['other', 'International SIM / eSIM'], ['other', 'Emergency contacts ki list']] },
};
const TODO_TPL = ['Tickets book karna', 'Hotel / stay book karna', 'Phone me offline maps download karna', 'Ghar walon ko itinerary batana', 'ATM / UPI limit check karna', 'Travel insurance dekhna', 'Weather forecast check karna', 'Power bank charge karna', 'Subah ka alarm set karna', 'Airport / station pickup fix karna'];

/* ---------- helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const str = (v, n) => String(v == null ? '' : v).slice(0, n);
const num = (v) => { const n = Number(v); return isFinite(n) && n > 0 ? Math.min(n, 1e9) : 0; };
const clampDays = (v) => Math.max(1, Math.min(60, parseInt(v, 10) || 1));
const clampPeople = (v) => Math.max(1, Math.min(50, parseInt(v, 10) || 1));
const isDate = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || '') ? v : '');

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseD = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (s, n) => { const d = parseD(s); d.setDate(d.getDate() + n); return ymd(d); };
const diffDays = (a, b) => Math.round((parseD(b) - parseD(a)) / 864e5);
const fmtD = (s, o) => parseD(s).toLocaleDateString('en-IN', o || { day: 'numeric', month: 'short' });
const hueOf = (id) => { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };

/* ---------- data ---------- */
function normalize(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((t) => t && typeof t === 'object' && String(t.name || '').trim()).map((t) => ({
    id: str(t.id || uid(), 40),
    name: str(t.name, 80).trim(),
    emoji: str(t.emoji || '🧳', 4) || '🧳',
    dest: str(t.dest, 80),
    start: isDate(t.start),
    end: isDate(t.end),
    days: clampDays(t.days),
    people: clampPeople(t.people),
    budget: num(t.budget),
    cur: CUR.includes(t.cur) ? t.cur : '₹',
    note: str(t.note, 1000),
    createdAt: str(t.createdAt || new Date().toISOString(), 40),
    plan: (Array.isArray(t.plan) ? t.plan : []).filter((x) => x && String(x.title || '').trim()).map((x) => ({
      id: str(x.id || uid(), 40), title: str(x.title, 120).trim(),
      day: Math.max(0, Math.min(60, parseInt(x.day, 10) || 0)),
      time: /^\d{2}:\d{2}$/.test(x.time || '') ? x.time : '',
      place: str(x.place, 80), note: str(x.note, 500), done: !!x.done,
    })),
    exp: (Array.isArray(t.exp) ? t.exp : []).filter((x) => x && num(x.amt) > 0).map((x) => ({
      id: str(x.id || uid(), 40), title: str(x.title || 'Kharcha', 80).trim() || 'Kharcha',
      amt: num(x.amt), cat: EXP_CATS.some((c) => c.id === x.cat) ? x.cat : 'other',
      day: Math.max(0, Math.min(60, parseInt(x.day, 10) || 0)),
      at: str(x.at || new Date().toISOString(), 40),
    })),
    pack: (Array.isArray(t.pack) ? t.pack : []).filter((x) => x && String(x.title || '').trim()).map((x) => ({
      id: str(x.id || uid(), 40), title: str(x.title, 80).trim(),
      grp: PACK_GRP.some((g) => g.id === x.grp) ? x.grp : 'other', done: !!x.done,
    })),
    todo: (Array.isArray(t.todo) ? t.todo : []).filter((x) => x && String(x.title || '').trim()).map((x) => ({
      id: str(x.id || uid(), 40), title: str(x.title, 120).trim(), done: !!x.done,
    })),
  }));
}

let api = null;
const view = { tripId: null, tab: 'plan' };
let root = null;
let focusSel = null;

const trips = () => api.state().trips;
const getTrip = (id) => trips().find((t) => t.id === id);
const spent = (t) => t.exp.reduce((a, e) => a + e.amt, 0);
const money = (t, n) => (t.cur.length > 1 ? t.cur + ' ' : t.cur) + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const daysOf = (t) => (t.start && t.end && t.end >= t.start ? Math.min(60, diffDays(t.start, t.end) + 1) : clampDays(t.days));
const endOf = (t) => (!t.start ? '' : t.end && t.end >= t.start ? t.end : addDays(t.start, daysOf(t) - 1));
const dayLabel = (t, d) => (d === 0 ? 'Flexible / Kabhi bhi' : t.start ? `Day ${d} · ${fmtD(addDays(t.start, d - 1), { weekday: 'short', day: 'numeric', month: 'short' })}` : `Day ${d}`);
const maxDay = (t) => Math.max(daysOf(t), ...t.plan.map((p) => p.day), ...t.exp.map((e) => e.day));

function status(t) {
  if (!t.start) return { k: 'nodate', text: 'Date tay nahi' };
  const today = ymd(new Date());
  if (today < t.start) {
    const d = diffDays(today, t.start);
    return { k: 'soon', text: d === 1 ? 'Kal se shuru! 🎉' : `${d} din baaki ⏳` };
  }
  if (today > endOf(t)) return { k: 'past', text: 'Ho gayi ✅' };
  return { k: 'on', text: 'Chal rahi hai 🔥' };
}

const bar = (pct, cls = '') => `<div class="bar sm ${cls}"><i style="width:${Math.max(0, Math.min(100, pct))}%"></i></div>`;
const budgetCls = (pct) => (pct > 100 ? 'over' : pct >= 80 ? 'warn' : '');

/* ---------- render: list ---------- */
function renderList() {
  const rank = { on: 0, soon: 1, nodate: 2, past: 3 };
  const arr = trips().map((t) => ({ t, s: status(t) })).sort((a, b) =>
    rank[a.s.k] - rank[b.s.k] ||
    (a.s.k === 'past' ? b.t.start.localeCompare(a.t.start) : (a.t.start || '~').localeCompare(b.t.start || '~')));

  const cards = arr.map(({ t, s }) => {
    const sp = spent(t);
    const pct = t.budget ? (sp / t.budget) * 100 : 0;
    const dates = t.start ? ` · ${fmtD(t.start)}${t.end ? ' – ' + fmtD(t.end) : ''}` : '';
    return `<article class="trip-card" data-act="open-trip" data-id="${esc(t.id)}" style="--h:${hueOf(t.id)}">
      <div class="tc-emoji">${esc(t.emoji)}</div>
      <div class="tc-body">
        <h3>${esc(t.name)}</h3>
        <p class="tc-sub">${t.dest ? '📍 ' + esc(t.dest) : 'Kahan? tay nahi'}${dates}</p>
        <div class="meta">
          <span class="pill">${esc(s.text)}</span>
          <span class="pill soft">${daysOf(t)} din · ${t.people} log</span>
          ${sp ? `<span class="pill soft">💸 ${esc(money(t, sp))}</span>` : ''}
        </div>
        ${t.budget ? bar(pct, budgetCls(pct)) : ''}
      </div>
    </article>`;
  }).join('');

  return `<div class="trips-top"><h2>Meri Trips 🧳</h2><p class="sub">Plan, kharcha aur packing, sab ek jagah</p></div>
    ${cards ? `<div class="list">${cards}</div>` : `<div class="empty"><span class="big">🧳</span><b>Abhi koi trip nahi</b><br>Neeche ＋ dabao aur pehli trip plan karo ✈️</div>`}`;
}

/* ---------- render: detail ---------- */
function renderDetail(t) {
  const sp = spent(t), left = t.budget - sp;
  const pct = t.budget ? (sp / t.budget) * 100 : 0;
  const s = status(t);
  const cnt = (arr) => [arr.filter((x) => x.done).length, arr.length];
  const prog = (label, [d, n]) => `<div class="mp"><span>${label}</span><b>${d}/${n}</b>${bar(n ? (d / n) * 100 : 0)}</div>`;
  const dates = t.start ? `${fmtD(t.start)}${t.end ? ' – ' + fmtD(t.end) : ''}` : '';

  const head = `<div class="trip-head" style="--h:${hueOf(t.id)}">
    <button class="icon-btn small" data-act="back" aria-label="Wapas">←</button>
    <div class="th-main"><h2>${esc(t.emoji)} ${esc(t.name)}</h2>
      <p class="sub">${t.dest ? '📍 ' + esc(t.dest) : ''}${dates ? (t.dest ? ' · ' : '') + esc(dates) : ''}</p></div>
    <button class="icon-btn small" data-act="share-trip" aria-label="Summary bhejo">📤</button>
    <button class="icon-btn small" data-act="edit-trip" aria-label="Trip edit karo">✏️</button>
  </div>`;

  const summary = `<section class="card tsum">
    <div class="meta"><span class="pill">${esc(s.text)}</span><span class="pill soft">${daysOf(t)} din</span><span class="pill soft">${t.people} log</span></div>
    <div class="stats">
      <div class="stat"><small>Budget</small><b>${t.budget ? esc(money(t, t.budget)) : '—'}</b></div>
      <div class="stat"><small>Kharcha</small><b>${esc(money(t, sp))}</b></div>
      <div class="stat ${t.budget && left < 0 ? 'bad' : ''}"><small>${t.budget && left < 0 ? 'Limit se zyada ⚠️' : 'Bacha'}</small><b>${t.budget ? esc((left < 0 ? '-' : '') + money(t, Math.abs(left))) : '—'}</b></div>
    </div>
    ${t.budget ? bar(pct, budgetCls(pct)) : ''}
    <div class="mprog">${prog('🗺️ Plan', cnt(t.plan))}${prog('🎒 Packing', cnt(t.pack))}${prog('✅ Yaad', cnt(t.todo))}</div>
    ${t.note ? `<p class="note">📝 ${esc(t.note)}</p>` : ''}
  </section>`;

  const tabs = [['plan', '🗺️ Plan'], ['money', '💸 Kharcha'], ['pack', '🎒 Packing'], ['todo', '✅ Yaad']]
    .map(([k, l]) => `<button data-act="tab" data-tab="${k}" class="${view.tab === k ? 'on' : ''}">${l}</button>`).join('');

  const body = { plan: planTab, money: moneyTab, pack: packTab, todo: todoTab }[view.tab](t);
  return `${head}${summary}<nav class="ttabs">${tabs}</nav>${body}`;
}

function planRow(p) {
  return `<div class="row ${p.done ? 'done' : ''}" data-id="${esc(p.id)}">
    <button class="check" data-act="toggle-plan" data-id="${esc(p.id)}" aria-label="Ho gaya">${p.done ? '✓' : ''}</button>
    <div class="rbody" data-act="edit-plan" data-id="${esc(p.id)}">
      <b>${esc(p.title)}</b>
      <div class="meta">${p.time ? `<span class="pill">🕒 ${esc(p.time)}</span>` : ''}${p.place ? `<span class="pill soft">📍 ${esc(p.place)}</span>` : ''}</div>
      ${p.note ? `<p class="note">${esc(p.note)}</p>` : ''}
    </div></div>`;
}

function planTab(t) {
  const byTime = (a, b) => (a.time || '99:99').localeCompare(b.time || '99:99');
  let html = `<div class="tab-actions">
    <button class="ghost" data-act="bucket-pick">🪣 Bucket se uthao</button>
    <button class="primary" data-act="add-plan" data-day="1">＋ Activity</button></div>`;
  for (let d = 1; d <= maxDay(t); d++) {
    const items = t.plan.filter((p) => p.day === d).sort(byTime);
    html += `<section class="day"><div class="day-head"><b>${esc(dayLabel(t, d))}</b><button class="mini" data-act="add-plan" data-day="${d}">＋</button></div>
      ${items.length ? items.map(planRow).join('') : '<p class="hint">Is din ka plan khaali hai, kuch crazy daalo 🤪</p>'}</section>`;
  }
  const flex = t.plan.filter((p) => p.day === 0).sort(byTime);
  if (flex.length) html += `<section class="day"><div class="day-head"><b>${esc(dayLabel(t, 0))}</b></div>${flex.map(planRow).join('')}</section>`;
  return html;
}

function moneyTab(t) {
  const sp = spent(t);
  const byCat = EXP_CATS.map((c) => ({ c, sum: t.exp.filter((e) => e.cat === c.id).reduce((a, e) => a + e.amt, 0) })).filter((x) => x.sum > 0);
  const list = [...t.exp].sort((a, b) => b.at.localeCompare(a.at));
  const catOf = (id) => EXP_CATS.find((c) => c.id === id) || EXP_CATS[5];
  return `<div class="tab-actions"><button class="primary" data-act="add-exp">＋ Kharcha add karo</button></div>
    <section class="card">
      <div class="stats">
        <div class="stat"><small>Total</small><b>${esc(money(t, sp))}</b></div>
        <div class="stat"><small>Per din</small><b>${esc(money(t, sp / daysOf(t)))}</b></div>
        <div class="stat"><small>Per person</small><b>${esc(money(t, sp / t.people))}</b></div>
      </div>
      ${byCat.length ? `<div class="cats">${byCat.map(({ c, sum }) => `<div class="crow" style="--h:${c.hue}"><span>${c.emoji} ${esc(c.name)}</span>${bar((sum / sp) * 100)}<b>${esc(money(t, sum))}</b></div>`).join('')}</div>` : '<p class="hint">Abhi koi kharcha nahi likha.</p>'}
    </section>
    ${list.map((e) => { const c = catOf(e.cat); return `<div class="row exp" data-act="edit-exp" data-id="${esc(e.id)}" style="--h:${c.hue}">
      <span class="ex-emoji">${c.emoji}</span>
      <div class="rbody"><b>${esc(e.title)}</b><div class="meta"><span class="pill">${esc(c.name)}</span>${e.day ? `<span class="pill soft">Day ${e.day}</span>` : ''}</div></div>
      <strong class="amt">${esc(money(t, e.amt))}</strong></div>`; }).join('')}`;
}

function packTab(t) {
  const done = t.pack.filter((x) => x.done).length;
  const tpl = Object.entries(PACK_TPL).map(([k, v]) => `<button class="chip" data-act="tpl-pack" data-k="${k}" style="--h:${v.hue}">${v.label}</button>`).join('');
  const groups = PACK_GRP.map((g) => {
    const items = t.pack.filter((x) => x.grp === g.id);
    if (!items.length) return '';
    return `<section class="day"><div class="day-head"><b>${g.emoji} ${esc(g.name)}</b><small>${items.filter((x) => x.done).length}/${items.length}</small></div>
      ${items.map((x) => `<div class="row slim ${x.done ? 'done' : ''}"><button class="check" data-act="toggle-pack" data-id="${esc(x.id)}">${x.done ? '✓' : ''}</button><div class="rbody"><b>${esc(x.title)}</b></div><button class="x" data-act="del-pack" data-id="${esc(x.id)}" aria-label="Hatao">✕</button></div>`).join('')}</section>`;
  }).join('');
  return `<section class="card"><div class="p-row"><strong>${done} / ${t.pack.length} pack ho gaya</strong><span>${t.pack.length ? Math.round((done / t.pack.length) * 100) : 0}%</span></div>${bar(t.pack.length ? (done / t.pack.length) * 100 : 0)}</section>
    <form class="quick" data-form="pack"><input name="title" placeholder="Kya rakhna hai? (e.g. Torch)" maxlength="80" required autocomplete="off">
      <select name="grp" aria-label="Group">${PACK_GRP.map((g) => `<option value="${g.id}">${g.emoji} ${esc(g.name)}</option>`).join('')}</select>
      <button class="primary" type="submit">＋</button></form>
    <p class="hint">Ready list ek tap me daalo:</p><div class="chips tpl">${tpl}</div>
    ${groups || '<div class="empty small"><span class="big">🎒</span>Packing list khaali hai</div>'}`;
}

function todoTab(t) {
  const done = t.todo.filter((x) => x.done).length;
  return `<section class="card"><div class="p-row"><strong>${done} / ${t.todo.length} yaad rakha</strong><span>${t.todo.length ? Math.round((done / t.todo.length) * 100) : 0}%</span></div>${bar(t.todo.length ? (done / t.todo.length) * 100 : 0)}</section>
    <form class="quick" data-form="todo"><input name="title" placeholder="Kya yaad rakhna hai? (e.g. Hotel confirm karna)" maxlength="120" required autocomplete="off">
      <button class="primary" type="submit">＋</button></form>
    <div class="chips tpl"><button class="chip" data-act="tpl-todo" style="--h:45">✨ Ready checklist daalo</button></div>
    ${t.todo.map((x) => `<div class="row slim ${x.done ? 'done' : ''}"><button class="check" data-act="toggle-todo" data-id="${esc(x.id)}">${x.done ? '✓' : ''}</button><div class="rbody"><b>${esc(x.title)}</b></div><button class="x" data-act="del-todo" data-id="${esc(x.id)}" aria-label="Hatao">✕</button></div>`).join('') || '<div class="empty small"><span class="big">📝</span>Tickets, bookings, documents... jo bhoolna nahi hai wo yahan likho</div>'}`;
}

function draw() {
  let t = view.tripId ? getTrip(view.tripId) : null;
  if (view.tripId && !t) view.tripId = null;
  root.innerHTML = t ? renderDetail(t) : renderList();
  if (focusSel) { const el = root.querySelector(focusSel); if (el) el.focus(); focusSel = null; }
}
function commit() { api.save(); api.refresh(); }

/* ---------- generic form dialog ---------- */
let dlg = null, formEl = null, ctx = null;
const flat = (fields) => fields.flat();

function fieldHtml(f, v) {
  const val = v[f.k] ?? '';
  const lab = esc(f.label);
  switch (f.type) {
    case 'textarea': return `<label>${lab}<textarea name="${f.k}" rows="2" maxlength="${f.max || 500}" placeholder="${esc(f.ph || '')}">${esc(val)}</textarea></label>`;
    case 'select': return `<label>${lab}<select name="${f.k}">${f.options.map(([ov, ol]) => `<option value="${esc(ov)}"${String(ov) === String(val) ? ' selected' : ''}>${esc(ol)}</option>`).join('')}</select></label>`;
    case 'checkbox': return `<label class="check-row"><input type="checkbox" name="${f.k}"${val ? ' checked' : ''}> <span>${lab}</span></label>`;
    case 'checks': return `<div class="checks"><p class="hint">${lab}</p>${f.options.map(([ov, ol]) => `<label class="check-row"><input type="checkbox" name="${f.k}" value="${esc(ov)}"> <span>${esc(ol)}</span></label>`).join('')}</div>`;
    default: return `<label>${lab}<input name="${f.k}" type="${f.type || 'text'}"${f.required ? ' required' : ''}${f.max ? ` maxlength="${f.max}"` : ''}${f.type === 'number' ? ' inputmode="decimal" step="any" min="0"' : ''} placeholder="${esc(f.ph || '')}" value="${esc(val)}"></label>`;
  }
}

function gather(fields) {
  const out = {};
  flat(fields).forEach((f) => {
    if (f.type === 'checkbox') out[f.k] = formEl.elements[f.k].checked;
    else if (f.type === 'checks') out[f.k] = [...formEl.querySelectorAll(`[name="${f.k}"]:checked`)].map((x) => x.value);
    else { const raw = formEl.elements[f.k].value; out[f.k] = f.type === 'number' ? (raw === '' ? '' : Number(raw)) : raw.trim(); }
  });
  return out;
}

function ensureDialog() {
  if (dlg) return;
  document.body.insertAdjacentHTML('beforeend', '<dialog id="dlgTripForm"><form id="tripForm" autocomplete="off"></form></dialog>');
  dlg = $('#dlgTripForm'); formEl = $('#tripForm');
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  formEl.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!ctx) return;
    if (ctx.onSubmit(gather(ctx.fields)) === false) return;
    dlg.close();
  });
  formEl.addEventListener('click', (e) => {
    if (e.target.closest('[data-close]')) dlg.close();
    else if (e.target.closest('[data-del]') && ctx && ctx.onDelete && confirm('Pakka delete karna hai? 🥺')) { ctx.onDelete(); dlg.close(); }
  });
}

function openForm(o) {
  ensureDialog();
  ctx = o;
  const v = o.values || {};
  const body = o.fields.map((f) => (Array.isArray(f) ? `<div class="two">${f.map((x) => fieldHtml(x, v)).join('')}</div>` : fieldHtml(f, v))).join('');
  formEl.innerHTML = `<div class="sheet-head"><h2>${esc(o.title)}</h2><button type="button" class="icon-btn small" data-close aria-label="Band karo">✕</button></div>${body}
    <div class="actions">${o.onDelete ? '<button type="button" class="danger" data-del>🗑️ Delete</button>' : ''}<button type="submit" class="primary">${esc(o.submit || 'Save karo 💖')}</button></div>`;
  dlg.showModal();
  if (o.autofocus) setTimeout(() => { const el = formEl.querySelector('input:not([type=checkbox])'); if (el) el.focus(); }, 60);
}

/* ---------- forms ---------- */
function tripForm(t) {
  const isNew = !t;
  openForm({
    title: isNew ? 'Nayi trip ✈️' : 'Trip edit karo ✏️',
    autofocus: isNew,
    values: isNew ? { emoji: '🧳', people: 1, cur: '₹', days: 3 } : { ...t, budget: t.budget || '' },
    fields: [
      { k: 'name', label: 'Trip ka naam', required: true, max: 80, ph: 'e.g. Manali ki pagalpanti 🏔️' },
      [{ k: 'emoji', label: 'Emoji', max: 4, ph: '🧳' }, { k: 'dest', label: 'Kahan?', max: 80, ph: 'Manali' }],
      [{ k: 'start', label: 'Kab se', type: 'date' }, { k: 'end', label: 'Kab tak', type: 'date' }],
      [{ k: 'days', label: 'Kitne din (date na ho to)', type: 'number' }, { k: 'people', label: 'Kitne log', type: 'number' }],
      [{ k: 'budget', label: 'Budget', type: 'number', ph: '20000' }, { k: 'cur', label: 'Currency', type: 'select', options: CUR.map((c) => [c, c]) }],
      { k: 'note', label: 'Trip note', type: 'textarea', max: 1000, ph: 'Kiske saath? Kaisi vibe? Kuch bhi 💭' },
    ],
    onDelete: isNew ? null : () => {
      api.state().trips = trips().filter((x) => x.id !== t.id);
      view.tripId = null; commit(); api.toast('Trip delete ho gayi');
    },
    onSubmit(d) {
      if (!d.name) return false;
      if (d.start && d.end && d.end < d.start) { api.toast('End date start se pehle nahi ho sakti 😅'); return false; }
      const f = { name: d.name, emoji: d.emoji || '🧳', dest: d.dest, start: d.start, end: d.end, days: clampDays(d.days), people: clampPeople(d.people), budget: num(d.budget), cur: d.cur, note: d.note };
      if (isNew) {
        const nt = { id: uid(), createdAt: new Date().toISOString(), plan: [], exp: [], pack: [], todo: [], ...f };
        trips().push(nt); view.tripId = nt.id; view.tab = 'plan';
        api.toast('Nayi trip ban gayi! 🧳✨');
      } else Object.assign(t, f);
      commit();
    },
  });
}

const dayOptions = (t, flexLabel) => [['0', flexLabel], ...Array.from({ length: maxDay(t) }, (_, i) => [String(i + 1), dayLabel(t, i + 1)])];

function planForm(t, p, day) {
  openForm({
    title: p ? 'Activity edit karo ✏️' : 'Kya karna hai? 🤩',
    autofocus: !p,
    values: p ? { ...p, day: String(p.day) } : { day: String(day) },
    fields: [
      { k: 'title', label: 'Kya karoge?', required: true, max: 120, ph: 'e.g. Paragliding, Sunset point, Cafe hopping' },
      [{ k: 'day', label: 'Kaunse din', type: 'select', options: dayOptions(t, 'Flexible') }, { k: 'time', label: 'Time', type: 'time' }],
      { k: 'place', label: 'Jagah (optional)', max: 80, ph: 'Solang Valley' },
      { k: 'note', label: 'Note (optional)', type: 'textarea', ph: 'Ticket, timing, kisko bulana hai...' },
      ...(p ? [{ k: 'done', label: 'Ho gaya! 🎉', type: 'checkbox' }] : []),
    ],
    onDelete: p ? () => { t.plan = t.plan.filter((x) => x.id !== p.id); commit(); } : null,
    onSubmit(d) {
      if (!d.title) return false;
      const f = { title: d.title, day: parseInt(d.day, 10) || 0, time: d.time, place: d.place, note: d.note };
      if (p) { Object.assign(p, f, { done: d.done }); } else { t.plan.push({ id: uid(), done: false, ...f }); }
      commit();
    },
  });
}

function expForm(t, e) {
  openForm({
    title: e ? 'Kharcha edit karo ✏️' : 'Kharcha likho 💸',
    autofocus: !e,
    values: e ? { ...e, day: String(e.day) } : { cat: 'food', day: '0' },
    fields: [
      { k: 'title', label: 'Kis cheez pe?', required: true, max: 80, ph: 'e.g. Hotel, Petrol, Momos' },
      [{ k: 'amt', label: 'Kitna', type: 'number', required: true, ph: '500' }, { k: 'cat', label: 'Category', type: 'select', options: EXP_CATS.map((c) => [c.id, `${c.emoji} ${c.name}`]) }],
      { k: 'day', label: 'Kaunse din', type: 'select', options: dayOptions(t, 'Koi din nahi') },
    ],
    onDelete: e ? () => { t.exp = t.exp.filter((x) => x.id !== e.id); commit(); } : null,
    onSubmit(d) {
      if (!d.title || !(Number(d.amt) > 0)) { api.toast('Naam aur amount dono daalo 🙂'); return false; }
      const f = { title: d.title, amt: num(d.amt), cat: d.cat, day: parseInt(d.day, 10) || 0 };
      if (e) Object.assign(e, f); else t.exp.push({ id: uid(), at: new Date().toISOString(), ...f });
      commit();
    },
  });
}

function bucketPick(t) {
  const avail = api.state().items.filter((i) => !i.done);
  if (!avail.length) { api.toast('Bucket list me koi baaki sapna nahi 🌈'); return; }
  openForm({
    title: 'Bucket se uthao 🪣',
    submit: 'Plan me daalo ✨',
    fields: [
      { k: 'day', label: 'Kaunse din?', type: 'select', options: dayOptions(t, 'Flexible') },
      { k: 'pick', label: 'Kaunse sapne is trip me poore karne hain?', type: 'checks', options: avail.map((i) => [i.id, i.title]) },
    ],
    onSubmit(d) {
      if (!d.pick.length) { api.toast('Kuch toh chuno 😄'); return false; }
      d.pick.forEach((id) => { const it = avail.find((i) => i.id === id); if (it) t.plan.push({ id: uid(), title: it.title, day: parseInt(d.day, 10) || 0, time: '', place: '', note: '', done: false }); });
      api.toast(`${d.pick.length} sapne plan me aa gaye 🎉`);
      commit();
    },
  });
}

/* ---------- share summary ---------- */
function summaryText(t) {
  const L = [`${t.emoji} ${t.name}`];
  L.push(`📍 ${t.dest || '—'}${t.start ? ` · ${fmtD(t.start)}${t.end ? ' – ' + fmtD(t.end) : ''}` : ''} · ${daysOf(t)} din · ${t.people} log`);
  if (t.budget) L.push(`💰 Budget ${money(t, t.budget)} · Kharcha ${money(t, spent(t))}`);
  else if (t.exp.length) L.push(`💸 Kharcha ${money(t, spent(t))}`);
  if (t.note) L.push('', `📝 ${t.note}`);
  if (t.plan.length) {
    L.push('', '🗺️ PLAN');
    for (const d of [...Array.from({ length: maxDay(t) }, (_, i) => i + 1), 0]) {
      const items = t.plan.filter((p) => p.day === d).sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
      if (!items.length) continue;
      L.push(dayLabel(t, d));
      items.forEach((p) => L.push(`  ${p.done ? '✅' : '⬜'} ${p.time ? p.time + ' ' : ''}${p.title}${p.place ? ' @ ' + p.place : ''}`));
    }
  }
  if (t.exp.length) { L.push('', '💸 KHARCHA'); t.exp.forEach((e) => L.push(`  • ${e.title} — ${money(t, e.amt)}`)); }
  if (t.pack.length) { const p = t.pack.filter((x) => !x.done); L.push('', `🎒 PACKING (${t.pack.length - p.length}/${t.pack.length} ho gaya)`); p.forEach((x) => L.push(`  ⬜ ${x.title}`)); }
  if (t.todo.length) { const p = t.todo.filter((x) => !x.done); L.push('', '✅ YAAD RAKHNA'); p.forEach((x) => L.push(`  ⬜ ${x.title}`)); }
  L.push('', 'BucketList app se 🪣');
  return L.join('\n');
}

async function shareText(title, text) {
  const cap = window.Capacitor;
  try {
    if (cap && cap.isNativePlatform && cap.isNativePlatform() && cap.Plugins && cap.Plugins.Share) {
      await cap.Plugins.Share.share({ title, text, dialogTitle: 'Trip summary bhejo' });
    } else if (navigator.share) {
      await navigator.share({ title, text });
    } else {
      await navigator.clipboard.writeText(text);
      api.toast('Summary copy ho gayi 📋');
    }
  } catch (e) {
    if (!e || e.name !== 'AbortError') api.toast('Share nahi ho paya 😕');
  }
}

/* ---------- events ---------- */
function onClick(e) {
  const el = e.target.closest('[data-act]');
  if (!el || !root.contains(el)) return;
  const act = el.dataset.act, id = el.dataset.id;
  const t = view.tripId ? getTrip(view.tripId) : null;

  switch (act) {
    case 'open-trip': view.tripId = id; view.tab = 'plan'; draw(); window.scrollTo({ top: 0 }); return;
    case 'back': view.tripId = null; draw(); window.scrollTo({ top: 0 }); return;
    case 'tab': view.tab = el.dataset.tab; draw(); return;
    case 'edit-trip': if (t) tripForm(t); return;
    case 'share-trip': if (t) shareText(t.name, summaryText(t)); return;
  }
  if (!t) return;
  switch (act) {
    case 'add-plan': planForm(t, null, Number(el.dataset.day) || 1); break;
    case 'edit-plan': planForm(t, t.plan.find((x) => x.id === id)); break;
    case 'toggle-plan': {
      const p = t.plan.find((x) => x.id === id); if (!p) break;
      p.done = !p.done;
      if (p.done) { api.burst(e.clientX, e.clientY); api.toast('Ek aur kaam ho gaya! 🎉'); }
      commit(); break;
    }
    case 'bucket-pick': bucketPick(t); break;
    case 'add-exp': expForm(t, null); break;
    case 'edit-exp': expForm(t, t.exp.find((x) => x.id === id)); break;
    case 'toggle-pack': {
      const x = t.pack.find((i) => i.id === id); if (!x) break;
      x.done = !x.done;
      if (x.done && t.pack.every((i) => i.done)) { api.burst(e.clientX, e.clientY); api.toast('Sab pack ho gaya! Bag ready 🎒🎉'); }
      commit(); break;
    }
    case 'del-pack': t.pack = t.pack.filter((i) => i.id !== id); commit(); break;
    case 'tpl-pack': {
      const tpl = PACK_TPL[el.dataset.k]; if (!tpl) break;
      const have = new Set(t.pack.map((i) => i.title.toLowerCase()));
      let n = 0;
      tpl.items.forEach(([grp, title]) => { if (!have.has(title.toLowerCase())) { t.pack.push({ id: uid(), title, grp, done: false }); n++; } });
      api.toast(n ? `${n} cheezein list me aa gayi 🎒` : 'Ye sab pehle se list me hai 👍');
      commit(); break;
    }
    case 'toggle-todo': {
      const x = t.todo.find((i) => i.id === id); if (!x) break;
      x.done = !x.done;
      if (x.done && t.todo.every((i) => i.done)) { api.burst(e.clientX, e.clientY); api.toast('Sab yaad rakh liya! 🧠✨'); }
      commit(); break;
    }
    case 'del-todo': t.todo = t.todo.filter((i) => i.id !== id); commit(); break;
    case 'tpl-todo': {
      const have = new Set(t.todo.map((i) => i.title.toLowerCase()));
      let n = 0;
      TODO_TPL.forEach((title) => { if (!have.has(title.toLowerCase())) { t.todo.push({ id: uid(), title, done: false }); n++; } });
      api.toast(n ? `${n} cheezein list me aa gayi ✅` : 'Ye sab pehle se list me hai 👍');
      commit(); break;
    }
  }
}

function onSubmit(e) {
  const f = e.target.closest('[data-form]');
  if (!f) return;
  e.preventDefault();
  const t = view.tripId ? getTrip(view.tripId) : null;
  if (!t) return;
  const title = f.elements.title.value.trim();
  if (!title) return;
  if (f.dataset.form === 'pack') {
    t.pack.push({ id: uid(), title: title.slice(0, 80), grp: f.elements.grp.value, done: false });
    focusSel = 'form[data-form="pack"] input[name="title"]';
  } else {
    t.todo.push({ id: uid(), title: title.slice(0, 120), done: false });
    focusSel = 'form[data-form="todo"] input[name="title"]';
  }
  commit();
}

/* ---------- public ---------- */
window.BLTrips = {
  normalize,
  init(a) {
    api = a;
    root = $('#viewTrips');
    root.addEventListener('click', onClick);
    root.addEventListener('submit', onSubmit);
  },
  render: draw,
  /* FAB (＋) button ka kaam, jo tab khula ho uske hisaab se */
  fab() {
    const t = view.tripId ? getTrip(view.tripId) : null;
    if (!t) { tripForm(null); return; }
    if (view.tab === 'plan') planForm(t, null, 1);
    else if (view.tab === 'money') expForm(t, null);
    else { const el = root.querySelector(`form[data-form="${view.tab}"] input[name="title"]`); if (el) { el.scrollIntoView({ block: 'center' }); el.focus(); } }
  },
};
})();
