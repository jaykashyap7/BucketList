(() => {
'use strict';

const KEY = 'bucketlist.v1';
const SNAP_KEY = 'bucketlist.snaps.v1';

const DEFAULT_CATS = [
  { id: 'places',    emoji: '✈️', name: 'Places',            hue: 200 },
  { id: 'things',    emoji: '🎯', name: 'Things to Do',      hue: 262 },
  { id: 'crazy',     emoji: '🤪', name: 'Crazy Stuff',       hue: 330 },
  { id: 'food',      emoji: '🍜', name: 'Food',              hue: 25  },
  { id: 'adventure', emoji: '🏔️', name: 'Adventure',         hue: 150 },
  { id: 'love',      emoji: '💕', name: 'With Loved Ones',   hue: 350 },
  { id: 'skills',    emoji: '🎨', name: 'Skills & Learning', hue: 282 },
  { id: 'own',       emoji: '🎁', name: 'Things to Own',     hue: 45  },
  { id: 'growth',    emoji: '🌱', name: 'Self Growth',       hue: 120 },
  { id: 'fun',       emoji: '🎶', name: 'Concerts & Events', hue: 310 },
];

const IDEAS = {
  places: ['Ladakh road trip', 'Northern lights dekhna', 'Santorini ka sunset', 'Japan me cherry blossom', 'Goa me new year', 'Kedarnath yatra', 'Maldives ka water villa', 'Paris me Eiffel Tower ke neeche picnic'],
  things: ['Ek din bina phone ke guzaarna', 'Apni diary likhna shuru karna', 'Ek poora saal journal maintain karna', 'Kisi ko surprise party dena', 'Ek khet me ek din kaam karna'],
  crazy: ['Skydiving karna', 'Bungee jumping', 'Raat ko bina plan ke random bus pakadna', 'Tomatina festival me jaana', 'Ek din ke liye alag naam se jeena', 'Hot air balloon ride', 'Stranger ko free hug dena'],
  food: ['Sab states ka famous khana try karna', 'Street food tour of Old Delhi', 'Sushi seekhna aur banana', 'Michelin star restaurant me khana', 'Poori raat dhaba hopping'],
  adventure: ['Scuba diving', 'Himalayan trek (Hampta/Kedarkantha)', 'River rafting in Rishikesh', 'Camping under the stars', 'Paragliding in Bir Billing'],
  love: ['Maa-papa ko foreign trip pe le jaana', 'Dost ke saath Eurotrip', 'Partner ke saath couple photoshoot', 'Bachpan ke doston ka reunion', 'Parivar ke saath ek lamba road trip'],
  skills: ['Guitar bajana seekhna', 'Swimming seekhna', 'Ek nayi language seekhna', 'Coding se apna app banana', 'Photography course', 'Cooking me master banna'],
  own: ['Apni khud ki car', 'DSLR camera', 'Apna ghar', 'Ek pyaara sa puppy', 'Ek solid travel backpack'],
  growth: ['Daily 5 baje uthna - 30 din', 'Ek marathon daud lena', 'Meditation 100 din', 'Saal me 24 books padhna', 'Apni fears ke saamne khade hona'],
  fun: ['Coldplay concert', 'IPL final stadium me dekhna', 'Sunburn / Tomorrowland festival', 'Apne favourite singer ko live sunna', 'Standup comedy show'],
};
const IDEAS_ANY = ['Kisi ke liye anonymous kuch accha karna', 'Ek naya shauk apnana', 'Aaj ke din ka ek crazy plan banana'];

const WHEN = [['any', 'Kabhi bhi'], ['year', 'Is saal'], ['next', 'Agle saal'], ['five', '5 saal me'], ['life', 'Life me ek baar']];
const PRI = [['1', '🌸 Ho jaye toh badhiya'], ['2', '💖 Pakka karna hai'], ['3', '🔥 Must must must!']];
const PRI_ICON = { '1': '🌸', '2': '💖', '3': '🔥' };
const WHEN_LABEL = Object.fromEntries(WHEN);

const TAGLINES = [
  'Sapne dekho, phir poore karo ✨',
  'Zindagi chhoti hai, list lambi rakho 🌈',
  'Ek ek karke sab tick karenge 💪',
  'Aaj kya naya karenge? 🎈',
  'Yaadein banao, photos toh free me aa jayengi 📸',
];
const PRAISE = ['Wooohooo! Ek sapna poora! 🎉', 'Tu toh chha gaya/gayi! 💖', 'Yeh hui na baat! ✨', 'Tick ho gaya! 🌟', 'Proud of you! 🥹'];

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const fmtDate = (iso) => iso ? new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '';

/* ---------- state ---------- */
function normalize(s) {
  s = s && typeof s === 'object' ? s : {};
  const cats = Array.isArray(s.cats) && s.cats.length ? s.cats : DEFAULT_CATS.map((c) => ({ ...c }));
  const items = (Array.isArray(s.items) ? s.items : [])
    .filter((i) => i && typeof i.title === 'string' && i.title.trim())
    .map((i) => ({
      id: String(i.id || uid()),
      title: i.title.trim().slice(0, 120),
      cat: String(i.cat || 'things'),
      note: String(i.note || '').slice(0, 500),
      when: WHEN_LABEL[i.when] ? i.when : 'any',
      pri: PRI_ICON[i.pri] ? String(i.pri) : '1',
      done: !!i.done,
      doneAt: i.doneAt || null,
      memory: String(i.memory || '').slice(0, 500),
      createdAt: i.createdAt || new Date().toISOString(),
    }));
  const trips = window.BLTrips ? window.BLTrips.normalize(s.trips) : [];
  return { v: 1, items, cats, trips, lastBackup: s.lastBackup || null };
}

let storageOK = true;
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return normalize(JSON.parse(raw));
  } catch (e) { storageOK = false; }
  return normalize({});
}
let state = load();

function save() {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
    autoSnapshot();
  } catch (e) {
    storageOK = false;
    toast('⚠️ Phone me save nahi ho pa raha! Backup download kar lo.');
  }
}

/* ---------- snapshots ---------- */
const hasData = () => state.items.length > 0 || state.trips.length > 0;
function getSnaps() {
  try { return JSON.parse(localStorage.getItem(SNAP_KEY)) || []; } catch (e) { return []; }
}
function putSnaps(arr) {
  try { localStorage.setItem(SNAP_KEY, JSON.stringify(arr.slice(0, 5))); } catch (e) { /* ignore */ }
}
function pushSnapshot(label) {
  if (!hasData()) return;
  const snaps = getSnaps();
  snaps.unshift({ at: new Date().toISOString(), label, data: state });
  putSnaps(snaps);
}
function autoSnapshot() {
  if (!hasData()) return;
  const snaps = getSnaps();
  const today = new Date().toDateString();
  if (snaps.length && new Date(snaps[0].at).toDateString() === today && snaps[0].label === 'auto') {
    snaps[0] = { at: new Date().toISOString(), label: 'auto', data: state };
    putSnaps(snaps);
  } else {
    pushSnapshot('auto');
  }
}

/* ---------- ui state ---------- */
const ui = { view: 'bucket', tab: 'all', cat: 'all', q: '', editId: null, pending: null };
const catById = (id) => state.cats.find((c) => c.id === id) || { id, emoji: '📌', name: 'Other', hue: 300 };

/* ---------- render ---------- */
function render() {
  renderNudge();
  if (ui.view === 'trips') { window.BLTrips.render(); return; }
  renderProgress();
  renderChips();
  renderList();
}

function renderProgress() {
  const total = state.items.length;
  const done = state.items.filter((i) => i.done).length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  $('#pText').textContent = `${done} / ${total} sapne poore`;
  $('#pPct').textContent = pct + '%';
  $('#pBar').style.width = pct + '%';
  let msg = 'Pehla sapna add karo, yahin se shuru! 🚀';
  if (total) {
    if (pct === 100) msg = 'Sab poore! Ab nayi list banao 🥳';
    else if (pct >= 60) msg = 'Bas thoda aur, tum kamaal ho 💫';
    else if (pct >= 25) msg = 'Badhiya chal raha hai! Keep going 🌈';
    else msg = 'Safar shuru ho chuka hai ✨';
  }
  $('#pMsg').textContent = msg;
}

function renderChips() {
  const box = $('#chips');
  const all = `<button class="chip ${ui.cat === 'all' ? 'on' : ''}" data-cat="all" style="--h:330">✨ Sab<small>${state.items.length}</small></button>`;
  const rest = state.cats.map((c) => {
    const n = state.items.filter((i) => i.cat === c.id).length;
    return `<button class="chip ${ui.cat === c.id ? 'on' : ''}" data-cat="${esc(c.id)}" style="--h:${c.hue}">${esc(c.emoji)} ${esc(c.name)}<small>${n}</small></button>`;
  }).join('');
  box.innerHTML = all + rest;
}

function visibleItems() {
  const q = ui.q.trim().toLowerCase();
  return state.items
    .filter((i) => (ui.tab === 'all' ? true : ui.tab === 'done' ? i.done : !i.done))
    .filter((i) => ui.cat === 'all' || i.cat === ui.cat)
    .filter((i) => !q || (i.title + ' ' + i.note + ' ' + i.memory).toLowerCase().includes(q))
    .sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (a.done) return (b.doneAt || '').localeCompare(a.doneAt || '');
      if (a.pri !== b.pri) return Number(b.pri) - Number(a.pri);
      return b.createdAt.localeCompare(a.createdAt);
    });
}

function renderList() {
  const items = visibleItems();
  $('#list').innerHTML = items.map((i) => {
    const c = catById(i.cat);
    return `<article class="item ${i.done ? 'done' : ''}" data-id="${esc(i.id)}" style="--h:${c.hue}">
      <button class="check" data-check aria-label="${i.done ? 'Wapas baaki karo' : 'Ho gaya!'}">${i.done ? '✓' : ''}</button>
      <div class="body">
        <h3>${esc(i.title)}</h3>
        <div class="meta">
          <span class="pill">${esc(c.emoji)} ${esc(c.name)}</span>
          ${i.when !== 'any' && !i.done ? `<span class="pill soft">⏰ ${esc(WHEN_LABEL[i.when])}</span>` : ''}
          ${!i.done ? `<span class="pill soft">${PRI_ICON[i.pri]}</span>` : `<span class="pill soft">✅ ${esc(fmtDate(i.doneAt))}</span>`}
        </div>
        ${i.note ? `<p class="note">${esc(i.note)}</p>` : ''}
        ${i.done && i.memory ? `<p class="mem">💭 ${esc(i.memory)}</p>` : ''}
      </div>
    </article>`;
  }).join('');

  const empty = $('#empty');
  if (!items.length) {
    empty.hidden = false;
    if (!state.items.length) {
      empty.innerHTML = '<span class="big">🪣</span><b>Bucket khaali hai!</b><br>Neeche ＋ dabao aur pehla sapna daalo ✨';
    } else if (ui.tab === 'done') {
      empty.innerHTML = '<span class="big">🌟</span><b>Abhi koi sapna poora nahi hua</b><br>Koi pick karo aur kar daalo!';
    } else {
      empty.innerHTML = '<span class="big">🔍</span><b>Kuch nahi mila</b><br>Filter ya search badal ke dekho';
    }
  } else {
    empty.hidden = true;
  }
}

function renderNudge() {
  const nudge = $('#nudge');
  if (!hasData()) { nudge.hidden = true; return; }
  const last = state.lastBackup ? new Date(state.lastBackup) : null;
  const days = last ? Math.floor((Date.now() - last.getTime()) / 864e5) : null;
  if (last === null) {
    $('#nudgeText').textContent = 'Abhi tak backup nahi liya 💾 Ek baar le lo!';
    nudge.hidden = false;
  } else if (days >= 7) {
    $('#nudgeText').textContent = `Last backup ${days} din pehle tha 💾`;
    nudge.hidden = false;
  } else {
    nudge.hidden = true;
  }
}

/* ---------- toast + confetti ---------- */
let toastT;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('show'), 2600);
}
function burst(x, y) {
  const bits = ['🎉', '✨', '💖', '🌸', '⭐', '🎈'];
  for (let n = 0; n < 16; n++) {
    const s = document.createElement('span');
    s.className = 'confetti';
    s.textContent = bits[n % bits.length];
    const a = Math.random() * Math.PI * 2, d = 60 + Math.random() * 120;
    s.style.left = x + 'px'; s.style.top = y + 'px';
    s.style.setProperty('--dx', Math.cos(a) * d + 'px');
    s.style.setProperty('--dy', Math.sin(a) * d - 40 + 'px');
    s.style.setProperty('--r', (Math.random() * 360 - 180) + 'deg');
    document.body.appendChild(s);
    setTimeout(() => s.remove(), 1000);
  }
}

/* ---------- item dialog ---------- */
const dlgItem = $('#dlgItem');
function fillSelects() {
  $('#fCat').innerHTML = state.cats.map((c) => `<option value="${esc(c.id)}">${esc(c.emoji)} ${esc(c.name)}</option>`).join('');
  $('#fWhen').innerHTML = WHEN.map(([v, l]) => `<option value="${v}">${l}</option>`).join('');
  $('#fPri').innerHTML = PRI.map(([v, l]) => `<option value="${v}">${l}</option>`).join('');
}
function syncDoneRows() {
  const on = $('#fDone').checked;
  $('#memRow').hidden = !on;
}
function openItem(id) {
  fillSelects();
  ui.editId = id || null;
  const it = id ? state.items.find((x) => x.id === id) : null;
  $('#itemTitle').textContent = it ? 'Sapna edit karo ✏️' : 'Naya sapna ✨';
  $('#fTitle').value = it ? it.title : '';
  $('#fCat').value = it ? it.cat : (ui.cat !== 'all' ? ui.cat : state.cats[0].id);
  $('#fWhen').value = it ? it.when : 'any';
  $('#fPri').value = it ? it.pri : '2';
  $('#fNote').value = it ? it.note : '';
  $('#fDone').checked = it ? it.done : false;
  $('#fMem').value = it ? it.memory : '';
  $('#doneRow').hidden = !it;
  $('#btnDelete').hidden = !it;
  syncDoneRows();
  dlgItem.showModal();
  if (!it) setTimeout(() => $('#fTitle').focus(), 50);
}

$('#fDone').addEventListener('change', syncDoneRows);
$('#btnIdea').addEventListener('click', () => {
  const pool = IDEAS[$('#fCat').value] || IDEAS_ANY;
  $('#fTitle').value = pool[Math.floor(Math.random() * pool.length)];
});
$('#formItem').addEventListener('submit', (e) => {
  e.preventDefault();
  const title = $('#fTitle').value.trim();
  if (!title) return;
  const data = {
    title, cat: $('#fCat').value, when: $('#fWhen').value, pri: $('#fPri').value,
    note: $('#fNote').value.trim(), memory: $('#fMem').value.trim(),
  };
  if (ui.editId) {
    const it = state.items.find((x) => x.id === ui.editId);
    const wasDone = it.done;
    Object.assign(it, data);
    it.done = $('#fDone').checked;
    it.doneAt = it.done ? (wasDone ? it.doneAt : new Date().toISOString()) : null;
    if (it.done && !wasDone) burst(innerWidth / 2, innerHeight / 2);
  } else {
    state.items.push({ id: uid(), done: false, doneAt: null, createdAt: new Date().toISOString(), ...data, memory: '' });
    toast('Bucket me add ho gaya! 🪣✨');
  }
  save();
  dlgItem.close();
  render();
});
$('#btnDelete').addEventListener('click', () => {
  if (!ui.editId) return;
  if (!confirm('Pakka delete karna hai? 🥺')) return;
  state.items = state.items.filter((x) => x.id !== ui.editId);
  save();
  dlgItem.close();
  render();
  toast('Delete ho gaya');
});

/* ---------- list interactions ---------- */
$('#list').addEventListener('click', (e) => {
  const card = e.target.closest('.item');
  if (!card) return;
  const id = card.dataset.id;
  if (e.target.closest('[data-check]')) {
    const it = state.items.find((x) => x.id === id);
    it.done = !it.done;
    it.doneAt = it.done ? new Date().toISOString() : null;
    save();
    if (it.done) {
      const r = e.target.closest('[data-check]').getBoundingClientRect();
      burst(r.left + r.width / 2, r.top + r.height / 2);
      toast(PRAISE[Math.floor(Math.random() * PRAISE.length)]);
    }
    render();
    return;
  }
  openItem(id);
});

$('#chips').addEventListener('click', (e) => {
  const b = e.target.closest('.chip');
  if (!b) return;
  ui.cat = b.dataset.cat;
  render();
});
document.querySelector('.tabs').addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  ui.tab = b.dataset.tab;
  document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x === b));
  render();
});
$('#q').addEventListener('input', (e) => { ui.q = e.target.value; renderList(); });
$('#btnAdd').addEventListener('click', () => (ui.view === 'trips' ? window.BLTrips.fab() : openItem(null)));

document.querySelector('.views').addEventListener('click', (e) => {
  const b = e.target.closest('[data-view]');
  if (!b) return;
  ui.view = b.dataset.view;
  document.querySelectorAll('.views button').forEach((x) => x.classList.toggle('on', x === b));
  $('#viewBucket').hidden = ui.view !== 'bucket';
  $('#viewTrips').hidden = ui.view !== 'trips';
  $('#btnAdd').setAttribute('aria-label', ui.view === 'trips' ? 'Naya add karo (trip)' : 'Naya sapna add karo');
  render();
  window.scrollTo({ top: 0 });
});

$('#btnSurprise').addEventListener('click', () => {
  const pool = state.items.filter((i) => !i.done);
  if (!pool.length) { toast('Pehle kuch sapne add karo! 🌈'); return; }
  const pick = pool[Math.floor(Math.random() * pool.length)];
  ui.tab = 'all'; ui.cat = 'all'; ui.q = ''; $('#q').value = '';
  document.querySelectorAll('.tabs button').forEach((x) => x.classList.toggle('on', x.dataset.tab === 'all'));
  render();
  const el = document.querySelector(`.item[data-id="${CSS.escape(pick.id)}"]`);
  if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.classList.add('hl'); }
  toast('Aaj ka plan: ' + pick.title + ' 🎲');
});

document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));
[dlgItem, $('#dlgSettings')].forEach((d) => d.addEventListener('click', (e) => { if (e.target === d) d.close(); }));

/* ---------- backup ---------- */
function buildBackup() {
  return JSON.stringify({ app: 'bucketlist', version: 1, exportedAt: new Date().toISOString(), data: state }, null, 2);
}
function backupName() {
  return `bucketlist-backup-${new Date().toISOString().slice(0, 10)}.json`;
}
function markBackedUp() {
  state.lastBackup = new Date().toISOString();
  save();
  render();
  renderSettings();
}
/* Android app (Capacitor) me blob download WebView me nahi chalta, isliye native share sheet se file bhejte hain */
const cap = window.Capacitor;
const isNative = !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform());

async function nativeBackup() {
  const { Filesystem, Share } = cap.Plugins || {};
  if (!Filesystem || !Share) throw new Error('plugins missing');
  const w = await Filesystem.writeFile({ path: backupName(), data: buildBackup(), directory: 'CACHE', encoding: 'utf8' });
  await Share.share({ title: 'BucketList backup', url: w.uri, dialogTitle: 'Backup kahan save karein? (Drive / WhatsApp / Files)' });
  markBackedUp();
  toast('Share sheet se Drive ya Files me save kar lena 💾');
}

function exportData() {
  if (isNative) {
    nativeBackup().catch(() => toast('Backup nahi ban paya 😕 Dobara try karo'));
    return;
  }
  const blob = new Blob([buildBackup()], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = backupName();
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  markBackedUp();
  toast('Backup file download ho gayi 💾');
}
async function shareData() {
  if (isNative) { exportData(); return; }
  const file = new File([buildBackup()], backupName(), { type: 'application/json' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: 'BucketList backup' });
      markBackedUp();
    } catch (e) { /* cancelled */ }
  } else {
    toast('Share is device pe nahi chalta, download use karo');
  }
}

function parseBackup(text) {
  const obj = JSON.parse(text);
  const data = obj && obj.data ? obj.data : obj;
  if (!data || !Array.isArray(data.items)) throw new Error('bad');
  return normalize(data);
}
$('#fileImport').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  try {
    ui.pending = parseBackup(await f.text());
    $('#importInfo').textContent = `Is file me ${ui.pending.items.length} sapne aur ${ui.pending.trips.length} trips mile 🎁. Kya karna hai?`;
    $('#importBox').hidden = false;
  } catch (err) {
    ui.pending = null;
    $('#importBox').hidden = true;
    toast('Yeh valid backup file nahi lagti 😕');
  }
});
$('#btnMerge').addEventListener('click', () => {
  if (!ui.pending) return;
  pushSnapshot('before-import');
  const have = new Set(state.items.map((i) => i.id));
  const haveCats = new Set(state.cats.map((c) => c.id));
  let added = 0;
  ui.pending.items.forEach((i) => { if (!have.has(i.id)) { state.items.push(i); added++; } });
  ui.pending.cats.forEach((c) => { if (!haveCats.has(c.id)) state.cats.push(c); });
  const haveTrips = new Set(state.trips.map((t) => t.id));
  let addedTrips = 0;
  ui.pending.trips.forEach((t) => { if (!haveTrips.has(t.id)) { state.trips.push(t); addedTrips++; } });
  finishImport(`${added} sapne aur ${addedTrips} trips merge hue ✨`);
});
$('#btnReplace').addEventListener('click', () => {
  if (!ui.pending) return;
  if (!confirm('Purani list hat jayegi (snapshot me safe rahegi). Continue?')) return;
  pushSnapshot('before-import');
  const lb = state.lastBackup;
  state = { ...ui.pending, lastBackup: lb };
  finishImport('Backup restore ho gaya 🎉');
});
$('#btnImportCancel').addEventListener('click', () => { ui.pending = null; $('#importBox').hidden = true; });
function finishImport(msg) {
  ui.pending = null;
  $('#importBox').hidden = true;
  save();
  render();
  renderSettings();
  toast(msg);
}

$('#btnExport').addEventListener('click', exportData);
$('#btnShare').addEventListener('click', shareData);
$('#nudgeBtn').addEventListener('click', exportData);

/* ---------- settings ---------- */
const dlgSettings = $('#dlgSettings');
function renderSettings() {
  $('#lastBackup').textContent = state.lastBackup
    ? `Last backup: ${fmtDate(state.lastBackup)} ✅`
    : 'Abhi tak backup nahi liya.';

  const snaps = getSnaps();
  $('#snaps').innerHTML = snaps.length
    ? snaps.map((s, i) => `<div class="snap"><span>${esc(fmtDate(s.at))} · ${s.data.items.length} sapne · ${(s.data.trips || []).length} trips${s.label === 'before-import' ? ' (import se pehle)' : ''}</span><button data-snap="${i}">Restore</button></div>`).join('')
    : '<p class="hint">Abhi koi snapshot nahi.</p>';

  const custom = state.cats.filter((c) => c.custom);
  $('#customCats').innerHTML = custom.length
    ? custom.map((c) => `<span class="chip" style="--h:${c.hue}">${esc(c.emoji)} ${esc(c.name)}<b data-delcat="${esc(c.id)}" title="Delete">✕</b></span>`).join('')
    : '<p class="hint">Apni khud ki categories yahan dikhengi.</p>';

  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const standalone = isNative || matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  $('#installHint').textContent = standalone
    ? 'App already install hai 🎉'
    : ios
      ? 'iPhone: Safari me Share ⬆️ dabao → "Add to Home Screen".'
      : 'Chrome me menu ⋮ → "Install app" / "Add to Home screen" bhi use kar sakte ho.';
}
$('#btnSettings').addEventListener('click', () => { renderSettings(); dlgSettings.showModal(); });

$('#snaps').addEventListener('click', (e) => {
  const b = e.target.closest('[data-snap]');
  if (!b) return;
  const snap = getSnaps()[Number(b.dataset.snap)];
  if (!snap) return;
  if (!confirm('Is snapshot ko restore karein? Abhi ki list ka bhi snapshot ban jayega.')) return;
  pushSnapshot('before-restore');
  state = normalize(snap.data);
  save(); render(); renderSettings();
  toast('Snapshot restore ho gaya 🛟');
});

$('#formCat').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = $('#cName').value.trim();
  if (!name) return;
  const emoji = $('#cEmoji').value.trim() || '📌';
  state.cats.push({ id: 'c_' + uid(), emoji, name, hue: Math.floor(Math.random() * 360), custom: true });
  $('#cName').value = ''; $('#cEmoji').value = '';
  save(); render(); renderSettings();
  toast('Nayi category ban gayi 🎨');
});
$('#customCats').addEventListener('click', (e) => {
  const b = e.target.closest('[data-delcat]');
  if (!b) return;
  const id = b.dataset.delcat;
  const used = state.items.filter((i) => i.cat === id).length;
  if (!confirm(used ? `Is category me ${used} sapne hain, woh "Things to Do" me chale jayenge. Delete karein?` : 'Category delete karein?')) return;
  state.items.forEach((i) => { if (i.cat === id) i.cat = 'things'; });
  state.cats = state.cats.filter((c) => c.id !== id);
  if (ui.cat === id) ui.cat = 'all';
  save(); render(); renderSettings();
});

$('#btnWipe').addEventListener('click', () => {
  if (!confirm('Sach me SAB mita dein? Pehle backup le lo!')) return;
  if (!confirm('Last confirm: sab kuch hat jayega (ek snapshot safe rahega).')) return;
  pushSnapshot('before-wipe');
  state = normalize({});
  save(); render(); renderSettings();
});

/* ---------- install + offline ---------- */
let deferredInstall = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstall = e;
  $('#btnInstall').hidden = false;
});
$('#btnInstall').addEventListener('click', async () => {
  if (!deferredInstall) return;
  deferredInstall.prompt();
  await deferredInstall.userChoice;
  deferredInstall = null;
  $('#btnInstall').hidden = true;
});
window.addEventListener('appinstalled', () => toast('App install ho gayi 🎉'));

if (isNative) {
  // App ke andar files already bundled hain: service worker ki zaroorat nahi
  $('#btnShare').hidden = true;
  $('#btnExport').textContent = '💾 Backup lo (Drive / WhatsApp / Files)';
  $('#fileImport').removeAttribute('accept');
}

if (!isNative && 'serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});

/* ---------- boot ---------- */
window.BLTrips.init({ state: () => state, save, refresh: render, toast, burst });
$('#tagline').textContent =TAGLINES[Math.floor(Math.random() * TAGLINES.length)];
if (!storageOK) toast('⚠️ Storage block hai, data save nahi hoga. Backup lete raho.');
render();
})();
